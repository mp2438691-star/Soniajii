# Sonia Birthday Website

Upload all files while preserving this structure:

- index.html
- images/sonia1.webp
- images/sonia2.webp
- images/sonia3.webp

Then enable GitHub Pages from the main branch and root folder.
